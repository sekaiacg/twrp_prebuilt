# alpha更新日志

## Magisk (6ecc04a4-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 不自动解锁设备块
- [General] 删除sepolicy临时文件
- [General] 使用官方NDK 25b
- [General] 移除全部rust代码
- [General] 重写MagiskHide，采用logcat实现。日志系统不正常的设备不要开启此功能。
- [App] 不主动请求通知权限
- [Zygisk] 卸载挂载不跳过com.android.systemui
- [App] 避免在绑定root服务之前获取数据
- [MagiskInit] 使用稳定的随机数种子
- [MagiskInit] 停止内置stub.apk
- [App] 修复网络状态监听
- [Zygisk] 用lsplt取代xhook
- [General] 移除addon.d支持
- [General] unshare magiskd
- [General] 将根目录递归绑定挂载到镜像
- [General] 模块挂载复用magisktmp的tmpfs
- [General] 始终对文件夹挂载tmpfs
- [General] 解析mountinfo以卸载挂载
- [General] 移动sepolicy.rules路径

# 上游更新日志

## Magisk (831a398b) (25206)

- Fix support on Linux < 3.6
- Several minor under-the-hood improvements

## Diffs to v25.2

- [General] Fix minor bug in module files mounting implementation
- [MagiskPolicy] Fix minor bug in command line argument parsing
- [Zygisk] Prevent crashing daemon in error
- [Zygisk] Rewrite zygote code injection with new loader library approach
- [App] Make stub patching 100% offline
