# alpha更新日志

重大行为变化：magiskd现在位于独立挂载命名空间，这也是su的全局挂载命名空间。
预计大部分su用例不受影响，如果有使用init挂载命名空间的用例，需要适配。

重大行为变化：用于模块挂载的文件框架现在是只读的，
即`$(magisk --path)/.magisk/modules`和`$(magisk --path)/.magisk/worker`均为只读，
只能通过`/data/adb/modules`路径修改。

重大行为变化：magisk tmpfs位置固定为`/sbin`或`/debug_ramdisk`。

## Magisk (709f25f6-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 添加遥测 https://t.me/s/magiskalpha/473
- [General] 不自动解锁设备块
- [General] 删除sepolicy临时文件
- [General] 使用官方NDK r25c
- [General] 移除全部rust代码
- [General] 重写MagiskHide，采用logcat实现。日志系统不正常的设备不要开启此功能。
- [App] 不主动请求通知权限
- [Zygisk] 卸载挂载不跳过com.android.systemui
- [General] 移除addon.d支持
- [General] unshare magiskd
- [General] 使用文件socket通信
- [General] 固定magisk tmpfs位置
- [MagiskPolicy] 删除magisk_exec和magisk_client
- [Zygisk] 重构加载方式
- [Resetprop] 支持免root使用，支持显示上下文

# 上游更新日志

### v26.1

- [App] Fix crashing when revoking root permissions
- [MagiskInit] Always prefer `ext4` partitions over `f2fs` when selecting the pre-init partition
- [General] Restore module files' context/owner/group from mirror. This is a regression introduced in v26.0

### v26.0

- [General] Bump minimum supported Android version to Android 6.0
- [General] New magic mount backend. It supports loading modules into system with `overlayfs` files injected
- [Zygisk] Release new API version 4
- [Zygisk] Prevent crashing daemon in error
- [Zygisk] Rewrite zygote code injection with new loader library approach
- [Zygisk] Rewrite code unloading implementation
- [MagiskBoot] Support amonet microloader devices
- [MagiskBoot] Always use lz4_legacy compression on v4 boot images. This fixes boot image patching issues on Android U preview.
- [MagiskInit] Support replacing existing \*.rc files in `overlay.d`
- [MagiskInit] Rewrite sepolicy.rules mounting and loading implementation
- [App] Make stub patching 100% offline
- [App] Support patching `init_boot.img` for Samsung ODIN firmware
- [MagiskPolicy] Fix minor bug in command line argument parsing
- [MagiskPolicy] Update rules to support Android U
