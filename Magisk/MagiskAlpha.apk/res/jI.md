# alpha更新日志

- 如果需要使用 heapprofd（Android Heap Profiler），请关闭zygisk并重启。
- `magisk`和`su`等二进制文件不再硬编码于`/system/bin/`目录下，而是从`PATH`环境变量中选择第一个可用位置。
- su现在会在解析已知选项后，原样传递剩余的参数到远程shell，由远程shell继续解析参数。

## Magisk (ccb264f3-alpha)
- [App] 还原boot镜像后删除备份文件
- [App] 不主动请求权限
- [General] 移除addon.d支持
- [App] 更新DoH
- [Zygisk] 修改 libzygisk.so 名字为 heapprofd_client.so
- [SU] 传递所有未知选项到远程 shell
- [App] 支持下载并修补 boot 映像

# 上游更新日志

## Magisk v30.6

### Hotfix

- [MagiskInit] Revert a change that could result in bootloops

### v30.5 Changelog

- [General] Migrate a significant portion of the codebase to Rust
- [General] Various minor bug fixes
- [General] Support installing Magisk into vendor_boot partition
- [Core] Improve Magisk specific files injection logic
- [MagiskSU] Add ability to restrict Linux capabilities even if running as root (uid=0)
- [MagiskSU] Fallback to older implementation when the kernel doesn't support zero userspace copy APIs
- [MagiskPolicy] Support new sepolicy binary format introduced in Android 16 QPR2
- [resetprop] Reduce property modification traces
- [resetprop] Properly support Android versions with property overrides

### Full Changelog: [here](https://topjohnwu.github.io/Magisk/changes.html)
